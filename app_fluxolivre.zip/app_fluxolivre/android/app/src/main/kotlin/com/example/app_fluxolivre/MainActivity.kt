package com.example.app_fluxolivre

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
